local component = require("component")
local sides = require("sides")
local os = require("os")

-- Asegúrate de que tienes una tarjeta de redstone instalada
local redstone = component.redstone

-- Función para el conteo regresivo y lanzamiento
local function launchMissile()
  print("Iniciando secuencia de lanzamiento...")

  -- Conteo regresivo de 5 segundos
  for i = 5, 1, -1 do
    print(i)
    os.sleep(1)
  end

  -- Enviar señal de redstone hacia la izquierda
  redstone.setOutput(sides.left, 15)
  os.sleep(1)  -- Mantener la señal por un segundo
  redstone.setOutput(sides.left, 0)

  print("Lanzamiento exitoso")
end

-- Iniciar el lanzamiento
launchMissile()